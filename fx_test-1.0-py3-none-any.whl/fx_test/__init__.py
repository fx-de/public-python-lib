from fx_test.ui import *

__all__ = ["fx_test"]

__version__ = "1.0"

def get_version():
    return __version__