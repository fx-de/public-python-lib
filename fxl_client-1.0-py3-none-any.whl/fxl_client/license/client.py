import functools
import json
import pathlib
import os
import sys
import warnings
from datetime import datetime
from fxl_core.license import Codec, LicenseException
from fxl_core.util.ntp import get_ntp_time
from fxl_core.logging.logger import Logger
from nacl.encoding import HexEncoder
from nacl.signing import VerifyKey
from pprint import pprint

ENCODING = "utf-8"
LICENSE_FILE_PATH = "/opt/fusionex/fx.lic"
WIN_LICENSE_FILE_PATH = "C:\fusionex\fx.lic"
license = None

class FXLClient():

    @staticmethod
    def validate(func):
        @functools.wraps(func)
        def wrap(*args, **kwargs):
            FXLClient.validate_file()
            value = func(*args, **kwargs)
            return value
        return wrap
        
    @staticmethod
    def validate_file():
        global license
        try:
            if not license:
                client_package = FXLClient.__read_license()

                license_key = client_package["license_key"].encode(ENCODING)

                product_id = client_package["product_id"]
                machine_id = Codec.get_machine_id()
                client_id = client_package["client_id"]
                license_key = client_package["license_key"]
                
                try:
                    license_data = Codec.prepare_license_data(product_id, machine_id=machine_id, client_id=client_id)
                    license_code = Codec.encode_license_data(license_data)

                    is_valid, extra_data = FXLClient.__validate_license(product_id, license_key, license_code)
                except Exception as e:
                    Logger.fail(e)
                    raise LicenseException("Invalid license file")
                
                Logger.info("License: {}".format(license_data))
                Logger.info("Data: {}".format(extra_data))
                
                if not is_valid:
                    raise LicenseException("Invalid license file")
                    
                FXLClient.__validate_expiry_date(extra_data)
                
                license = extra_data
                Logger.good("License validated successfully")
        except Exception as e:
            license = None
            Logger.fail(e)
            #raise SystemExit(e)
            warnings.filterwarnings("ignore")
            sys.excepthook = FXLClient.__exception_handler
            sys.exit(e)

    def __exception_handler(exception_type, exception, traceback):
        Logger.fail("{}: {}".format(exception_type.__name__, exception))

    @staticmethod
    def generate_request_file(client_id):
        try:
            if not Codec.validate_email(client_id):
                raise LicenseException("client_id: Invalid email format: {}".format(client_id))

            machine_id = Codec.get_machine_id()
            machine_name = Codec.get_machine_name()
            request = {
                "client_id": client_id,
                "machine_name": machine_name,
                "mid": machine_id,
            }
            with open("lic.req", "w") as out:
                json.dump(request, out)
        except Exception as e:
            Logger.fail(e)

    @staticmethod
    def get_machine_id():
        try:
            return Codec.get_machine_id()
        except Exception as e:
            Logger.fail(e)

    @staticmethod
    def get_licence_path():        
        if os.name == 'nt':
            return WIN_LICENSE_FILE_PATH
        else:
            return LICENSE_FILE_PATH

    def __read_license():
        # read license file from file
        path = pathlib.Path(FXLClient.get_licence_path())
        if not path.exists():
            raise LicenseException("License file not found")

        try:
            with open(str(path), "r") as f:
                license = json.load(f)

            keys = ["product_id", "client_id", "license_key"]
            for key in keys:
                if key not in license.keys():
                    raise

            return license
        except:
            raise LicenseException("Invalid license file")

    def __validate_license(product_id, license_key, license_code):
        delimiter = product_id[len(product_id) - 4:]
        keys = license_key.split(delimiter)

        verify_key = keys[0].encode(ENCODING)
        signature = keys[1].encode(ENCODING)
        signed_message = keys[2].encode(ENCODING)
        extra_data = keys[3]

        verify_key = VerifyKey(verify_key, encoder=HexEncoder)
        message = verify_key.verify(signed_message, signature, encoder=HexEncoder).decode(ENCODING)

        message = Codec.decode_license_data(message)
        local_message = Codec.decode_license_data(license_code)
        extra_data = Codec.decode_license_data(extra_data)

        return message == local_message, extra_data

    def __validate_expiry_date(extra_data):
        extra_data = json.loads(extra_data)
        
        keys = ["expired", "use_ntp"]
        for key in keys:
            if key not in extra_data.keys():
                raise LicenseException("Invalid license file")
        
        if not extra_data["expired"]:
            return True
        
        if extra_data["use_ntp"] == True:
            current_time = get_ntp_time()
        else:
            current_time = datetime.utcnow()
        
        expired = datetime.strptime(extra_data["expired"], "%Y-%m-%d")
        
        if current_time > expired:
            raise LicenseException("License is expired")
        
        return True