import argparse
from .license.client import FXLClient

VERSION = "1.0"
        
def validate_file():
    parser = argparse.ArgumentParser(
        prog="validate_file",
        description=(
            "Validate license file."
        )
    )

    parser.add_argument(
        "-v",
        "--version",
        help="Show the %(prog)s version number",
        action="version",
        version="%(prog)s {}".format(VERSION),
    )

    return FXLClient.validate_file()
      
def get_machine_id():
    parser = argparse.ArgumentParser(
        prog="get_machine_id",
        description=(
            "Get machine id."
        )
    )

    parser.add_argument(
        "-v",
        "--version",
        help="Show the %(prog)s version number",
        action="version",
        version="%(prog)s {}".format(VERSION),
    )

    return FXLClient.get_machine_id()

def generate_request_file():
    parser = argparse.ArgumentParser(
        prog="generate_license_request_file",
        description=(
            "Generate license request file for client."
        )
    )
    
    parser.add_argument("-e", "--email", help="Client Email", required=True)

    parser.add_argument(
        "-v",
        "--version",
        help="Show the %(prog)s version number",
        action="version",
        version="%(prog)s {}".format(VERSION),
    )
    args = parser.parse_args()

    FXLClient.generate_request_file(args.email)