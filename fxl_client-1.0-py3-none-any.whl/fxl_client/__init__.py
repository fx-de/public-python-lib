from fxl_core.license import Codec
from fxl_core.logging import Logger
from fxl_client.license import *

__all__ = ["fxl_client"]

__version__ = "1.0"

def get_version():
    Logger.info("Version: {}".format(__version__))
    return __version__